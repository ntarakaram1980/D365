﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Tooling.Connector;
using Pike.Xrm.CICD.RulesEngineComponentCloner;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pike.Xrm.CICD.BugFixComponentChecker
{
    class Program
    {
        static void Main(string[] args)
        {

            string source = ConfigurationManager.AppSettings["Source"];
            string Target_PK_Config = ConfigurationManager.AppSettings["Target1"];
            string Target_PK_Apps = ConfigurationManager.AppSettings["Target2"];
            string Target_PK_Security = ConfigurationManager.AppSettings["Target3"];
            string Target_PK_WebResources = ConfigurationManager.AppSettings["Target4"];
            string Target_PK_ProcessesPlugins = ConfigurationManager.AppSettings["Target5"];
            string Target_PK_Flows = ConfigurationManager.AppSettings["Target6"];
            string Target_ConnRef = ConfigurationManager.AppSettings["ConnRef"];
            string Target_ConnRefLimit =  ConfigurationManager.AppSettings["ConnRefLimit"];
            var connectionString = ConfigurationManager.ConnectionStrings["cs"].ConnectionString;
            try
            {
                if (args.Length >= 3)
                {
                    string server = args[0];
                    string username = args[1];
                    string password = args[2];


                    connectionString = string.Format(connectionString, server, username, password);
                    CrmServiceClient conn = new CrmServiceClient(connectionString);

                    IOrganizationService service;

                    service = (IOrganizationService)conn.OrganizationWebProxyClient != null ? (IOrganizationService)conn.OrganizationWebProxyClient : (IOrganizationService)conn.OrganizationServiceProxy;

                    service = (IOrganizationService)conn.OrganizationWebProxyClient != null ? (IOrganizationService)conn.OrganizationWebProxyClient : (IOrganizationService)conn.OrganizationServiceProxy;

                    StringBuilder sb = new StringBuilder();
                    var sManager = new SolutionManager(service);
                    var settings = new CopySettings
                    {
                        SourceSolutions = sManager.RetrieveSolutions(source).ToList(),
                        TargetSolutions = null
                    };
                   
                    
                    sb.AppendLine("<b>Please stop using below connection references as they already exceeded 10 </b> <br/>");
                    sb = CheckConnrefMaxsetting(Target_ConnRef, service, sb, int.Parse(Target_ConnRefLimit));

                    Console.WriteLine(sb.ToString());
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message );
            }
        }

        private static StringBuilder CheckConnrefMaxsetting(string source,  IOrganizationService service, StringBuilder sb, int limit)
        {
            var sManager = new SolutionManager(service);

            var settings = new CopySettings
            {
                SourceSolutions = sManager.RetrieveSolutions(source).ToList(),
                TargetSolutions = null
            };


            OptionMetadataCollection _omc = ((OptionSetMetadata)((RetrieveOptionSetResponse)service.Execute(
            new RetrieveOptionSetRequest
            {
                Name = "componenttype"
            })).OptionSetMetadata).Options;


            return sManager.CheckConnrefMaxsetting(settings, _omc, sb, limit);
        }


        //private static List<Entity>  Checkcomponets(StringBuilder sb, List<Entity> sourceList, string source, List<string> target,  IOrganizationService service)
        //{

        //    var sManager = new SolutionManager(service);

        //    var settings = new CopySettings
        //    {
        //        SourceSolutions = sManager.RetrieveSolutions(source).ToList(),
        //        TargetSolutions = sManager.RetrieveAllSolutions(target).ToList()
        //    };
        //    //settings.TargetSolutions.Add();

        //    OptionMetadataCollection _omc = ((OptionSetMetadata)((RetrieveOptionSetResponse)service.Execute(
        //    new RetrieveOptionSetRequest
        //    {
        //        Name = "componenttype"
        //    })).OptionSetMetadata).Options;

            
        //    return sManager.CheckComponents(sourceList, settings, _omc, sb);
        //}
    }
}
