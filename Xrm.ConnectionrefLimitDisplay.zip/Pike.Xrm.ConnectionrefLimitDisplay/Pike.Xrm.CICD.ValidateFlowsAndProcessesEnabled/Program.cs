﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Tooling.Connector;
using Pike.Xrm.CICD.RulesEngineComponentCloner;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pike.Xrm.CICD.ValidateFlowsAndProcessesEnabled
{
    class Program
    {
        static void Main(string[] args)
        {
            string disable = string.Empty;
            string source = ConfigurationManager.AppSettings["Source"];
            string target = ConfigurationManager.AppSettings["Target"];
            try
            {
                if (args.Length >= 3)
                {
                    string server = args[0];
                    string username = args[1];
                    string password = args[2];

                    if (args.Length == 4)
                    {
                        disable = args[3];
                    }

                    var connectionString = ConfigurationManager.ConnectionStrings["cs"].ConnectionString;
                    
                    connectionString = string.Format(connectionString, server, username, password);
                    CrmServiceClient conn = new CrmServiceClient(connectionString);
                    conn.OrganizationServiceProxy.Timeout = new TimeSpan(0, 10, 0);
                    IOrganizationService service;

                    service = (IOrganizationService)conn.OrganizationWebProxyClient != null ? (IOrganizationService)conn.OrganizationWebProxyClient : (IOrganizationService)conn.OrganizationServiceProxy;

                    var sManager = new SolutionManager(service);

                    var Source = sManager.RetrieveSolutions(source);
                    var settings = new CopySettings
                    {
                        SourceSolutions = Source.ToList()
                    };
                    OptionMetadataCollection _omc = ((OptionSetMetadata)((RetrieveOptionSetResponse)service.Execute(
                    new RetrieveOptionSetRequest
                    {
                        Name = "componenttype"
                    })).OptionSetMetadata).Options;
                    Dictionary<string, string> result = new Dictionary<string, string>();
                    // List<string> output = sManager.ListFlows(settings, _omc);
                    if (disable.ToLower().Equals("yes"))
                    {
                         result = sManager.ListFlows(settings, _omc, false);
                    }
                    else
                    {
                        result = sManager.ListFlows(settings, _omc, true);
                    }
                    StringBuilder Output = new StringBuilder();
                    foreach( var val in result)
                    {
                        Output.AppendLine(val.Key + " : " + val.Value);
                    }
                    Console.WriteLine(Output.ToString());
                   
                }
                else
                {
                    throw new  System.SystemException("CRM Server, UserName and password is required ");
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

    }
}
//if (output.Count > 0)
//{
//    Console.WriteLine("Flows/process are not turned on: ");
//    int i = 0;
//    foreach (var s in output)
//    {

//        i++;

//        Console.Write(s);
//        if (i != output.Count)
//        {
//            Console.WriteLine(",");
//        }

//    }
//}