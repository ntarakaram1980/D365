﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pike.Xrm.CICD.RulesEngineComponentCloner
{
    class Program
    {
        static void Main(string[] args)
        {
           
            string source = ConfigurationManager.AppSettings["Source"];
            string webResourceTarget = ConfigurationManager.AppSettings["WebResourceTarget"];
            string pluginAddemblyTarget = ConfigurationManager.AppSettings["PluginAddemblyTarget"];
            

           
            try
            {

                var connectionString = ConfigurationManager.ConnectionStrings["cs"].ConnectionString;
                CrmServiceClient conn = new CrmServiceClient(connectionString);

                IOrganizationService service;

                service = (IOrganizationService)conn.OrganizationWebProxyClient != null ? (IOrganizationService)conn.OrganizationWebProxyClient : (IOrganizationService)conn.OrganizationServiceProxy;

                var sManager = new SolutionManager(service);
              
               
                var Source = sManager.RetrieveSolutions(source);
                var WebResourceTarget = sManager.RetrieveSolutions(webResourceTarget);
                var PluginAddemblyTarget = sManager.RetrieveSolutions(pluginAddemblyTarget);
                var settings = new CopySettings
                {
                    SourceSolutions = Source.ToList(),
                    TargetSolutions = WebResourceTarget.ToList()
                };
                OptionMetadataCollection _omc = ((OptionSetMetadata)((RetrieveOptionSetResponse)service.Execute(
                new RetrieveOptionSetRequest
                {
                    Name = "componenttype"
                })).OptionSetMetadata).Options;

                sManager.CopyComponents(settings, _omc, 61);

                settings = new CopySettings
                {
                    SourceSolutions = Source.ToList(),
                    TargetSolutions = PluginAddemblyTarget.ToList()

                };
                sManager.CopyComponents(settings, _omc, 92);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

               // Console.Out
            }
        }

    }
}

