﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;


namespace Pike.Xrm.CICD.RulesEngineComponentCloner
{
    internal class SolutionManager
    {
        private readonly IOrganizationService service;

        public SolutionManager(IOrganizationService service)
        {
            this.service = service;
        }

        public IEnumerable<Entity> RetrieveSolutions(string name)
        {
            var qe = new QueryExpression
            {
                EntityName = "solution",
                ColumnSet = new ColumnSet(new[]{
                                            "publisherid", "installedon", "version",
                                            "uniquename", "friendlyname", "description",
                                            "ismanaged"
                                        }),
                Criteria = new FilterExpression
                {
                    Conditions =
                    {
                        new ConditionExpression("isvisible", ConditionOperator.Equal, true),
                        new ConditionExpression("uniquename", ConditionOperator.Equal, name)
                    }
                }
            };

            return service.RetrieveMultiple(qe).Entities;
        }

        internal void CopyComponents(CopySettings settings, OptionMetadataCollection omc, int cType)
        {

            var sourceComponents = RetrieveComponentsFromSolutions(settings.SourceSolutions.Select(s => s.Id).ToList());
            var targetComponents = RetrieveComponentsFromSolutions(settings.TargetSolutions.Select(s => s.Id).ToList());


            foreach (var target in settings.TargetSolutions)
            {
                AddSolutionComponentRequest request = new AddSolutionComponentRequest();
                try
                {
                    foreach (var component in sourceComponents.Where(s => s.GetAttributeValue<OptionSetValue>("componenttype").Value == cType))
                    {

                        var c = component.Attributes.ToList();
                        var d = component.GetAttributeValue<Guid>("solutioncomponentid");
                        bool skipFlag = false;
                        foreach (var tc in targetComponents)
                        {
                            if (component.GetAttributeValue<Guid>("objectid").ToString() == tc.GetAttributeValue<Guid>("objectid").ToString())
                            {
                                skipFlag = true;
                                break;
                            }
                        }
                        if (!skipFlag)
                        {
                            if ((component.GetAttributeValue<OptionSetValue>("componenttype").Value == cType))
                            { 
                                request = new AddSolutionComponentRequest
                                {
                                    AddRequiredComponents = false,
                                    ComponentId = component.GetAttributeValue<Guid>("objectid"),
                                    ComponentType = component.GetAttributeValue<OptionSetValue>("componenttype").Value,
                                    SolutionUniqueName = target.GetAttributeValue<string>("uniquename"),
                                };
                                service.Execute(request);
                            }
                        }

                    }
                }
                catch (Exception e)
                {
                    Console.Write("error" + e.Message);
                    Console.Read();
                }
            }
        }
        internal List<Entity> RetrieveComponentsFromSolutions(List<Guid> solutionsIds)
        {
            var queryExpression = new QueryExpression("solutioncomponent")
            {
                ColumnSet = new ColumnSet(true),
                Criteria = new FilterExpression
                {
                    Conditions =
                    {
                        new ConditionExpression("solutionid", ConditionOperator.In, solutionsIds.ToArray()),
                    }
                },
                LinkEntities =
                {
                    new LinkEntity
                    {
                        LinkFromEntityName = "solutioncomponent",
                        LinkFromAttributeName = "solutionid",
                        LinkToAttributeName = "solutionid",
                        LinkToEntityName = "solution",
                        EntityAlias = "solution",
                        Columns = new ColumnSet("ismanaged")
                    }
                }
            };

            return service.RetrieveMultiple(queryExpression).Entities.ToList();
        }


    }
}