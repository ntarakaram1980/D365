﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using System.Collections;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Extensions.DependencyModel;

namespace Pike.Xrm.CICD.RulesEngineComponentCloner
{
    public class SolutionManager
    {
        private readonly IOrganizationService service;

        public SolutionManager(IOrganizationService service)
        {
            this.service = service;
        }

        public IEnumerable<Entity> RetrieveSolutions(string name)
        {
            var qe = new QueryExpression
            {
                EntityName = "solution",
                // ColumnSet = new ColumnSet(new[]{"publisherid", "installedon", "version","uniquename", "friendlyname", "description","ismanaged"}),
                ColumnSet = new ColumnSet(true),
                Criteria = new FilterExpression
                {
                    Conditions =
                    {
                        new ConditionExpression("isvisible", ConditionOperator.Equal, true),
                        new ConditionExpression("uniquename", ConditionOperator.Equal, name)
                    }
                }
            };
            return service.RetrieveMultiple(qe).Entities;
        }

        //public IEnumerable<Entity> RetrieveAllSolutions(List<string> name)
        //{
        //    var qe = new QueryExpression
        //    {
        //        EntityName = "solution",
        //        // ColumnSet = new ColumnSet(new[]{"publisherid", "installedon", "version","uniquename", "friendlyname", "description","ismanaged"}),
        //        ColumnSet = new ColumnSet(true),
        //        Criteria = new FilterExpression
        //        {
        //            Conditions =
        //            {
        //                new ConditionExpression("isvisible", ConditionOperator.Equal, true),
        //                new ConditionExpression("uniquename", ConditionOperator.In, name)
        //            }
        //        }
        //    };
        //    return service.RetrieveMultiple(qe).Entities;
        //}
        //public int CopyConfigComponents(CopySettings settings, OptionMetadataCollection omc)
        //{

        //    var sourceComponents = RetrieveComponentsFromSolutions(settings.SourceSolutions.Select(s => s.Id).ToList());
        //    var targetComponents = RetrieveComponentsFromSolutions(settings.TargetSolutions.Select(s => s.Id).ToList());

        //    int iCount = 0;
        //    foreach (var target in settings.TargetSolutions)
        //    {
        //        AddSolutionComponentRequest request = new AddSolutionComponentRequest();
        //        try
        //        {
        //            foreach (var component in sourceComponents)
        //            {

        //                var c = component.Attributes.ToList();
        //                var d = component.GetAttributeValue<Guid>("solutioncomponentid");
        //                bool skipFlag = false;
        //                foreach (var tc in targetComponents)
        //                {
        //                    if (component.GetAttributeValue<Guid>("objectid").ToString() == tc.GetAttributeValue<Guid>("objectid").ToString())
        //                    {
        //                        skipFlag = true;
        //                        break;
        //                    }
        //                }
        //                if (!skipFlag)
        //                {
        //                    if ((component.GetAttributeValue<OptionSetValue>("componenttype").Value == 1))
        //                    {
        //                        request = new AddSolutionComponentRequest
        //                        {
        //                            AddRequiredComponents = false,
        //                            DoNotIncludeSubcomponents = true,
        //                            ComponentId = component.GetAttributeValue<Guid>("objectid"),
        //                            ComponentType = component.GetAttributeValue<OptionSetValue>("componenttype").Value,
        //                            SolutionUniqueName = target.GetAttributeValue<string>("uniquename"),
        //                        };
        //                        iCount++;
        //                        service.Execute(request);
        //                    }
        //                    else
        //                    {
        //                        request = new AddSolutionComponentRequest
        //                        {
        //                            AddRequiredComponents = false,
        //                            //DoNotIncludeSubcomponents = true,
        //                            ComponentId = component.GetAttributeValue<Guid>("objectid"),
        //                            ComponentType = component.GetAttributeValue<OptionSetValue>("componenttype").Value,
        //                            SolutionUniqueName = target.GetAttributeValue<string>("uniquename"),
        //                        };
        //                        iCount++;
        //                        service.Execute(request);
        //                    }
        //                }

        //            }
        //        }
        //        catch (Exception e)
        //        {
        //            Console.Write("error" + e.Message);
        //            Console.Read();
        //        }
        //    }
        //    return iCount;
        //}

        //public Dictionary<Guid,int> GetComponentNames(List<Entity> list)
        //{
        //    StringBuilder sb = new StringBuilder();
        //    Dictionary<Guid, int> output = new Dictionary<Guid, int>();

        //    foreach (var i in list)
        //    {
        //        output.Add(i.Id, i.GetAttributeValue<OptionSetValue>("componenttype").Value);
        //    }
        //    return output;

        //}

        public StringBuilder CheckConnrefMaxsetting(CopySettings settings, OptionMetadataCollection omc, StringBuilder sb, int limit)
        {
            var sourceComponents = RetrieveComponentsFromSolutions(settings.SourceSolutions.Select(s => s.Id).ToList());
            List<Guid> ListComp = new List<Guid>(); 
            foreach (var component in sourceComponents.Where(s => s.GetAttributeValue<OptionSetValue>("componenttype").Value == 10349))
            {
                
                RetrieveDependentComponentsRequest dependentComponentsRequest =
                new RetrieveDependentComponentsRequest
                {
                    ComponentType = component.GetAttributeValue<OptionSetValue>("componenttype").Value,
                    ObjectId = component.GetAttributeValue<Guid>("objectid")
                };
                RetrieveDependentComponentsResponse dependentComponentsResponse =
                    (RetrieveDependentComponentsResponse)service.Execute(dependentComponentsRequest);

                if (dependentComponentsResponse.EntityCollection.Entities.Any() == false)
                    continue;

                var Connrefcomponent = RetrieveConnRefComponents(component.GetAttributeValue<Guid>("objectid"));
                if (Connrefcomponent.Count > 0)
                {

                    if(dependentComponentsResponse.EntityCollection.Entities.Count >= limit)
                        sb.AppendLine($"Found { dependentComponentsResponse.EntityCollection.Entities.Count} dependencies for the Connectionref <b> {Connrefcomponent[0].GetAttributeValue<string>("connectionreferencedisplayname")} </b> <br/>");
                }
            }
            return sb;
        }
      

        //public int CopyComponents(CopySettings settings, OptionMetadataCollection omc, int cType)
        //{

        //    var sourceComponents = RetrieveComponentsFromSolutions(settings.SourceSolutions.Select(s => s.Id).ToList());
        //    var targetComponents = RetrieveComponentsFromSolutions(settings.TargetSolutions.Select(s => s.Id).ToList());

        //    int iCount = 0;
        //    foreach (var target in settings.TargetSolutions)
        //    {
        //        AddSolutionComponentRequest request = new AddSolutionComponentRequest();
        //        try
        //        {
        //            foreach (var component in sourceComponents.Where(s => s.GetAttributeValue<OptionSetValue>("componenttype").Value == cType))
        //            {

        //                var c = component.Attributes.ToList();
        //                var d = component.GetAttributeValue<Guid>("solutioncomponentid");
        //                bool skipFlag = false;
        //                foreach (var tc in targetComponents)
        //                {
        //                    if (component.GetAttributeValue<Guid>("objectid").ToString() == tc.GetAttributeValue<Guid>("objectid").ToString())
        //                    {
        //                        skipFlag = true;
        //                        break;
        //                    }
        //                }
        //                if (!skipFlag)
        //                {
        //                    if ((component.GetAttributeValue<OptionSetValue>("componenttype").Value == cType))
        //                    { 
        //                        request = new AddSolutionComponentRequest
        //                        {
        //                            AddRequiredComponents = false,
        //                            ComponentId = component.GetAttributeValue<Guid>("objectid"),
        //                            ComponentType = component.GetAttributeValue<OptionSetValue>("componenttype").Value,
        //                            SolutionUniqueName = target.GetAttributeValue<string>("uniquename"),
        //                        };
        //                        iCount++;
        //                        service.Execute(request);
        //                    }
        //                }

        //            }
        //        }
        //        catch (Exception e)
        //        {
        //            Console.Write("error" + e.Message);
        //            Console.Read();
        //        }
        //    }
        //    return iCount;
        //}


        //public void CopyComponents(CopySettings settings, OptionMetadataCollection omc)
        //{

        //    var sourceComponents = RetrieveComponentsFromSolutions(settings.SourceSolutions.Select(s => s.Id).ToList());
        //    var targetComponents = RetrieveComponentsFromSolutions(settings.TargetSolutions.Select(s => s.Id).ToList());

        //    int iCount = 0;
        //    foreach (var target in settings.TargetSolutions)
        //    {
        //        AddSolutionComponentRequest request = new AddSolutionComponentRequest();
        //        try
        //        {
        //            foreach (var component in sourceComponents)
        //            {

        //                var c = component.Attributes.ToList();
        //                var d = component.GetAttributeValue<Guid>("solutioncomponentid");
        //                bool skipFlag = false;
        //                foreach (var tc in targetComponents)
        //                {
        //                    if (component.GetAttributeValue<Guid>("objectid").ToString() == tc.GetAttributeValue<Guid>("objectid").ToString())
        //                    {
        //                        skipFlag = true;
        //                        break;
        //                    }
        //                }
        //                if (!skipFlag)
        //                {
        //                    if ((component.GetAttributeValue<OptionSetValue>("componenttype").Value == 1))
        //                    {
        //                        request = new AddSolutionComponentRequest
        //                        {
        //                            AddRequiredComponents = false,
        //                            DoNotIncludeSubcomponents = true,
        //                            ComponentId = component.GetAttributeValue<Guid>("objectid"),
        //                            ComponentType = component.GetAttributeValue<OptionSetValue>("componenttype").Value,
        //                            SolutionUniqueName = target.GetAttributeValue<string>("uniquename"),
        //                        };
        //                        iCount++;
        //                        service.Execute(request);
        //                    }
        //                    else
        //                    {
        //                        request = new AddSolutionComponentRequest
        //                        {
        //                            AddRequiredComponents = false,
        //                            ComponentId = component.GetAttributeValue<Guid>("objectid"),
        //                            ComponentType = component.GetAttributeValue<OptionSetValue>("componenttype").Value,
        //                            SolutionUniqueName = target.GetAttributeValue<string>("uniquename"),
        //                        };
        //                        iCount++;
        //                        service.Execute(request);
        //                    }
        //                }

        //            }
        //        }
        //        catch (Exception e)
        //        {
        //            Console.Write("error" + e.Message);
        //            Console.Read();
        //        }
        //    }
        //}

        //public List<Entity> SourceComponentDetails(CopySettings settings)
        //{
        //    return RetrieveComponentsFromSolutions(settings.SourceSolutions.Select(s => s.Id).ToList());
           
        //}


        //public List<Entity> CheckComponents(List<Entity> sourceComponents, CopySettings settings, OptionMetadataCollection omc, StringBuilder sb)
        //{
        //    List<Entity> PatchEntities = new List<Entity>();
        //    PatchEntities = RetrievePatchesforSolution(settings.TargetSolutions.Select(s => s.Id).ToList());
        //    foreach (var target in PatchEntities)
        //    {
        //        settings.TargetSolutions.Add(target);
        //    }

        //    var targetComponents = RetrieveComponentsFromSolutions(settings.TargetSolutions.Select(s => s.Id).ToList());
        //    List<Entity> compList = new List<Entity>();

        //    foreach (var target in settings.TargetSolutions)
        //    {
        //        try
        //        {
        //                foreach (var tc in targetComponents)
        //                {
        //                    foreach (var component in sourceComponents)
        //                    {
        //                        if (component.GetAttributeValue<Guid>("objectid").ToString() == tc.GetAttributeValue<Guid>("objectid").ToString())
        //                        {
        //                        compList.Add(component);
        //                            break;
        //                        }
        //                    }
        //                }
                                           
        //            foreach (var comp in compList)
        //            {
        //                if (sourceComponents.Contains(comp))
        //                {
        //                    sourceComponents.Remove(comp);
        //                }
        //            }
        //        }
        //        catch (Exception e)
        //        {
        //            throw e;
        //        }
        //    }
           
        //    return sourceComponents;
        //}
    


        //public Dictionary<string, string> ListFlows(CopySettings settings, OptionMetadataCollection omc, bool turnon)
        //{

        //    var sourceComponents = RetrieveComponentsFromSolutions(settings.SourceSolutions.Select(s => s.Id).ToList());
        //    List<Guid> wfList = new List<Guid>();

        //    Dictionary<string, string> dictSuccess = new Dictionary<string, string>();
        //    Dictionary<string, string> dictFailure = new Dictionary<string, string>();
        //    ExecuteMultipleRequest requestWithResults = new ExecuteMultipleRequest()
        //    {
        //        Settings = new ExecuteMultipleSettings()
        //        {
        //            ContinueOnError = true,
        //            ReturnResponses = true
        //        },
        //        Requests = new OrganizationRequestCollection()
        //    };
        //    List<string> flowList = new List<string>();
        //    foreach (var component in sourceComponents)
        //    {
        //        var ComponentId = component.GetAttributeValue<Guid>("objectid");
        //        wfList.Add(ComponentId);
        //    }
        //    int statecode = 0;
        //    statecode = turnon ? 0 : 1;
          
        //    var output = RetrieveProcesssFromSolutions(wfList, statecode);
        //    foreach (var list1 in output)
        //    {
        //        if (list1 != null)
        //        {
        //            if (list1.GetAttributeValue<OptionSetValue>("statecode").Value == statecode)
        //            {
        //                Entity workflow = new Entity("workflow");
        //                workflow["workflowid"] = list1.GetAttributeValue<Guid>("workflowid");
        //                workflow["statecode"] = new OptionSetValue((int)(turnon ? statecode + 1 : statecode - 1));
        //                workflow["statuscode"] = new OptionSetValue((int)(turnon ? statecode + 2 : statecode));
        //                UpdateRequest recordUpdateRequest = new UpdateRequest { Target = workflow };
        //                requestWithResults.Requests.Add(recordUpdateRequest);
        //                flowList.Add(list1.GetAttributeValue<string>("name").ToString());
        //            }
        //        }
        //    }

        //    if (requestWithResults.Requests.Count >= 0)
        //    {
        //        ExecuteMultipleResponse responseWithResults = (ExecuteMultipleResponse)service.Execute(requestWithResults);

        //        if (responseWithResults.Responses.Count > 0)
        //        {
        //            int i = 0;
        //            foreach (var responseItem in responseWithResults.Responses)
        //            {
        //                if (responseItem.Fault != null)
        //                    dictFailure.Add(flowList[i], responseItem.Fault.Message);
        //                i++;
        //            }
        //        }
        //    }
        //    return dictFailure;
        //}

        

        internal List<Entity> RetrieveProcesssFromSolutions(List<Guid> workflowId, int statecode)
        {
            var queryExpression = new QueryExpression("workflow")
            {
                ColumnSet = new ColumnSet(true),

                Criteria = new FilterExpression
                {
                    Conditions =
                        {
                            new ConditionExpression("workflowid", ConditionOperator.In, workflowId.ToArray()),
                        }
                }
            };
            return service.RetrieveMultiple(queryExpression).Entities.ToList();
        }

     

        public List<Entity> RetrieveConnRefComponents(Guid conid)
        {
            var queryExpression = new QueryExpression("connectionreference")
            {
                ColumnSet = new ColumnSet(true),

                Criteria = new FilterExpression
                {
                    Conditions =
                        {
                            new ConditionExpression("connectionreferenceid", ConditionOperator.Equal, conid),
                        }
                }
            };
            return service.RetrieveMultiple(queryExpression).Entities.ToList();

        }

     


        public List<Entity> RetrieveComponentsFromSolutions(List<Guid> solutionsIds)
        {
            var queryExpression = new QueryExpression("solutioncomponent")
            {
                ColumnSet = new ColumnSet(true),
                Criteria = new FilterExpression
                {
                    Conditions =
                    {
                        new ConditionExpression("solutionid", ConditionOperator.In, solutionsIds.ToArray()),
                    }
                },
                LinkEntities =
                {
                    new LinkEntity
                    {
                        LinkFromEntityName = "solutioncomponent",
                        LinkFromAttributeName = "solutionid",
                        LinkToAttributeName = "solutionid",
                        LinkToEntityName = "solution",
                        EntityAlias = "solution",
                        Columns = new ColumnSet("ismanaged")
                    }
                }
            };

            return service.RetrieveMultiple(queryExpression).Entities.ToList();
        }


    }
}