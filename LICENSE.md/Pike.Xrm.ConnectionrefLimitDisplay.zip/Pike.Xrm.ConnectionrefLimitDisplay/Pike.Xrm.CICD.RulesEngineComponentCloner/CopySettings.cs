﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
namespace Pike.Xrm.CICD.RulesEngineComponentCloner
{
    internal class CopySettings
    {
        public List<int> ComponentsTypes { get; set; }
        public List<Entity> SourceSolutions { get; set; }
        public List<Entity> TargetSolutions { get; set; }
    }
}
